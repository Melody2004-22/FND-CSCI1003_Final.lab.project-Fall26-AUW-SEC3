
/* =====================================================
   SAFEHER - COMPLETE JAVASCRIPT
   HTML + CSS + JavaScript Only
   No Firebase | No Login | No Signup

   Features:
   1. Emergency SOS
   2. Siren Sound
   3. Call 999
   4. Live Location
   5. Location Sharing
   6. Fake Incoming Call
   7. Emergency Contacts
   8. Safe Journey
   9. SafeSpots
   10. Bottom Navigation
   ===================================================== */


/* =====================================================
   1. GLOBAL VARIABLES
   ===================================================== */

const $ = (id) => document.getElementById(id);

let currentLocation = null;

let sirenContext = null;
let sirenOscillator = null;
let sirenGain = null;
let sirenInterval = null;

let ringtoneInterval = null;
let fakeCallTimer = null;
let toastTimer = null;


/* =====================================================
   2. LOCAL STORAGE
   Save and load contacts and journey information
   ===================================================== */

function saveData(key, value) {
    try {
        localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
        console.error("Could not save data:", error);
        showToast("Could not save data in this browser.");
    }
}


function getData(key, fallback = []) {
    try {
        const savedData = localStorage.getItem(key);

        return savedData
            ? JSON.parse(savedData)
            : fallback;

    } catch (error) {
        console.error("Could not load data:", error);
        return fallback;
    }
}


/* =====================================================
   3. TOAST MESSAGE
   Display small notification messages
   ===================================================== */

function showToast(message) {
    const toast = $("toast");

    if (!toast) return;

    toast.textContent = message;
    toast.classList.add("show");

    clearTimeout(toastTimer);

    toastTimer = setTimeout(() => {
        toast.classList.remove("show");
    }, 2800);
}


/* =====================================================
   4. HTML SECURITY
   Escape text before displaying user-entered values
   ===================================================== */

function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, (character) => {
        const characters = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#039;"
        };

        return characters[character];
    });
}


/* =====================================================
   5. PHONE NUMBER FORMATTING
   Convert Bangladeshi local numbers to international format
   ===================================================== */

function formatPhone(phone) {
    let number = String(phone).replace(/\D/g, "");

    if (number.startsWith("0")) {
        number = "88" + number;
    } else if (!number.startsWith("880")) {
        number = "880" + number;
    }

    return number;
}


/* =====================================================
   6. AUDIO SYSTEM
   Create browser audio for siren and fake call
   ===================================================== */

function getAudioContext() {
    const AudioClass =
        window.AudioContext ||
        window.webkitAudioContext;

    if (!AudioClass) {
        showToast("Audio is not supported by this browser.");
        return null;
    }

    if (!sirenContext) {
        sirenContext = new AudioClass();
    }

    if (sirenContext.state === "suspended") {
        sirenContext.resume();
    }

    return sirenContext;
}


/* =====================================================
   7. SIREN SOUND
   Play emergency siren
   ===================================================== */

function playSiren() {
    stopSiren();

    const audio = getAudioContext();

    if (!audio) return;

    sirenOscillator = audio.createOscillator();
    sirenGain = audio.createGain();

    sirenOscillator.type = "sawtooth";
    sirenOscillator.frequency.value = 700;

    sirenGain.gain.value = 0.10;

    sirenOscillator.connect(sirenGain);
    sirenGain.connect(audio.destination);

    sirenOscillator.start();

    let highTone = false;

    sirenInterval = setInterval(() => {
        if (!sirenOscillator || !sirenContext) return;

        highTone = !highTone;

        sirenOscillator.frequency.setTargetAtTime(
            highTone ? 1000 : 650,
            audio.currentTime,
            0.08
        );

    }, 450);
}


/* Stop siren */

function stopSiren() {
    if (sirenInterval) {
        clearInterval(sirenInterval);
        sirenInterval = null;
    }

    if (sirenOscillator) {
        try {
            sirenOscillator.stop();
        } catch (error) {
            // Already stopped
        }

        sirenOscillator = null;
    }

    if (sirenGain) {
        try {
            sirenGain.disconnect();
        } catch (error) {
            // Already disconnected
        }

        sirenGain = null;
    }
}


/* =====================================================
   8. FAKE CALL RINGTONE
   Simulated ringtone using Web Audio API
   ===================================================== */

function playRingtone() {
    stopRingtone();

    const playTone = () => {
        const audio = getAudioContext();

        if (!audio) return;

        [440, 480].forEach((frequency, index) => {
            const oscillator = audio.createOscillator();
            const gain = audio.createGain();

            oscillator.type = "sine";
            oscillator.frequency.value = frequency;

            gain.gain.value = 0.08;

            oscillator.connect(gain);
            gain.connect(audio.destination);

            const startTime =
                audio.currentTime + index * 0.25;

            oscillator.start(startTime);
            oscillator.stop(startTime + 0.18);
        });
    };

    playTone();

    ringtoneInterval = setInterval(playTone, 1200);
}


function stopRingtone() {
    if (ringtoneInterval) {
        clearInterval(ringtoneInterval);
        ringtoneInterval = null;
    }
}


/* =====================================================
   9. LOCATION SYSTEM
   Get current location using browser Geolocation API
   ===================================================== */

function getCurrentLocation() {
    return new Promise((resolve, reject) => {

        if (!navigator.geolocation) {
            reject({
                code: 0,
                message: "Geolocation is not supported."
            });

            return;
        }

        navigator.geolocation.getCurrentPosition(

            (position) => {
                const location = {
                    latitude: position.coords.latitude,
                    longitude: position.coords.longitude,
                    accuracy: position.coords.accuracy
                };

                currentLocation = location;

                resolve(location);
            },

            (error) => {
                reject(error);
            },

            {
                enableHighAccuracy: true,
                timeout: 20000,
                maximumAge: 0
            }
        );
    });
}


/* =====================================================
   10. MAP URL FUNCTIONS
   Use OpenStreetMap instead of Google Maps iframe
   ===================================================== */

function getMapURL(latitude, longitude) {

    const left = longitude - 0.01;
    const right = longitude + 0.01;

    const bottom = latitude - 0.01;
    const top = latitude + 0.01;

    return (
        "https://www.openstreetmap.org/export/embed.html?" +
        `bbox=${left},${bottom},${right},${top}` +
        `&layer=mapnik&marker=${latitude},${longitude}`
    );
}


function getShareURL(latitude, longitude) {
    return (
        `https://www.google.com/maps?q=${latitude},${longitude}`
    );
}


/* =====================================================
   11. SHOW MAP INSIDE WEBSITE
   Display current location with a marker
   ===================================================== */

function showMap(elementId, latitude, longitude) {

    const map = $(elementId);

    if (!map) return;

    const mapURL = getMapURL(latitude, longitude);

    map.innerHTML = `
        <iframe
            src="${mapURL}"
            title="Your current location on map"
            loading="lazy"
            referrerpolicy="no-referrer-when-downgrade">
        </iframe>
    `;
}


/* =====================================================
   12. LIVE LOCATION
   Find and display the user's current location
   ===================================================== */

async function findMyLocation() {

    $("locationStatus").textContent =
        "Detecting your current location...";

    try {
        const location = await getCurrentLocation();

        showMap(
            "locationMap",
            location.latitude,
            location.longitude
        );

        $("locationStatus").textContent =
            `Location found! Latitude: ${location.latitude.toFixed(5)}, ` +
            `Longitude: ${location.longitude.toFixed(5)}. ` +
            `Accuracy: approximately ${Math.round(location.accuracy)} metres.`;

        showToast("Your location is now visible.");

    } catch (error) {

        console.error("Location error:", error);

        if (error.code === 1) {
            $("locationStatus").textContent =
                "Location permission denied. Please allow location access.";

        } else if (error.code === 2) {
            $("locationStatus").textContent =
                "Your device could not determine your location.";

        } else if (error.code === 3) {
            $("locationStatus").textContent =
                "Location request timed out. Please try again.";

        } else {
            $("locationStatus").textContent =
                "Location is unavailable. Check your browser settings.";
        }

        showToast("Unable to detect your location.");
    }
}


/* =====================================================
   13. LOCATION SHARING
   Share location through WhatsApp, SMS or device share
   ===================================================== */

function getLocationMessage() {

    if (!currentLocation) return null;

    const mapLink = getShareURL(
        currentLocation.latitude,
        currentLocation.longitude
    );

    return (
        "I want to share my current location with you.\n" +
        "My location: " + mapLink
    );
}


function shareWhatsApp() {

    const message = getLocationMessage();

    if (!message) {
        showToast("Please find your location first.");
        return;
    }

    const url =
        "https://wa.me/?text=" +
        encodeURIComponent(message);

    window.open(url, "_blank");
}


function shareSMS() {

    const message = getLocationMessage();

    if (!message) {
        showToast("Please find your location first.");
        return;
    }

    window.location.href =
        "sms:?body=" + encodeURIComponent(message);
}


async function nativeShare() {

    const message = getLocationMessage();

    if (!message) {
        showToast("Please find your location first.");
        return;
    }

    if (navigator.share) {

        try {
            await navigator.share({
                title: "SafeHer Location",
                text: message
            });

        } catch (error) {
            // Sharing cancelled by user
        }

    } else {
        shareWhatsApp();
    }
}


/* =====================================================
   14. EMERGENCY CONTACTS
   Add, delete and display trusted contacts
   ===================================================== */

function getContacts() {
    return getData("safeher_contacts", []);
}


function saveContacts(contacts) {
    saveData("safeher_contacts", contacts);
}


/* Add new contact */

function addContact() {

    const name = $("contactName").value.trim();
    const phone = $("contactPhone").value.trim();

    if (!name || !phone) {
        showToast("Please enter name and phone number.");
        return;
    }

    if (!/^[0-9+\-\s()]{7,20}$/.test(phone)) {
        showToast("Please enter a valid phone number.");
        return;
    }

    const contacts = getContacts();

    contacts.push({
        id: Date.now(),
        name: name,
        phone: phone
    });

    saveContacts(contacts);

    $("contactName").value = "";
    $("contactPhone").value = "";

    renderContacts();

    showToast("Emergency contact added.");
}


/* Delete contact */

function deleteContact(id) {

    const contacts = getContacts().filter(
        contact => contact.id !== id
    );

    saveContacts(contacts);

    renderContacts();

    showToast("Contact deleted.");
}


/* Display contacts */

function renderContacts() {

    const list = $("contactList");

    if (!list) return;

    const contacts = getContacts();

    if (contacts.length === 0) {

        list.innerHTML =
            '<p class="empty-message">No contacts added yet.</p>';

        renderTripContactOptions();

        return;
    }

    list.innerHTML = contacts.map(contact => `

        <div class="contact-item">

            <div class="contact-info">

                <strong>${escapeHTML(contact.name)}</strong>

                <small>${escapeHTML(contact.phone)}</small>

            </div>

            <div class="contact-actions">

                <a class="call-contact"
                   href="tel:${escapeHTML(contact.phone)}">
                    Call
                </a>

                <button class="delete-contact"
                        data-delete-contact="${contact.id}">
                    Delete
                </button>

            </div>

        </div>

    `).join("");

    renderTripContactOptions();
}


/* =====================================================
   15. EMERGENCY SOS
   Activate alarm, vibration and location support
   ===================================================== */

async function activateSOS() {

    $("sosOverlay").hidden = false;

    $("sosMessage").textContent =
        "Emergency mode activated. You can call 999 or contact your trusted people.";

    // Play siren
    playSiren();

    // Vibrate device if supported
    if (navigator.vibrate) {
        navigator.vibrate([
            500, 200, 500, 200, 800
        ]);
    }

    try {

        const location = await getCurrentLocation();

        const message =
            "I need help. Please check on me. My location: " +
            getShareURL(
                location.latitude,
                location.longitude
            );

        $("sosOverlay").dataset.message = message;

        $("sosMessage").textContent =
            "Your location is ready. You can share it with your emergency contact.";

    } catch (error) {

        console.error(error);

        $("sosMessage").textContent =
            "Location unavailable. You can still call 999 or contact your saved contacts.";
    }
}


/* Share SOS message with first saved contact */

function shareSOSWhatsApp() {

    const contacts = getContacts();

    if (contacts.length === 0) {
        showToast("Please add an emergency contact first.");
        return;
    }

    const message =
        $("sosOverlay").dataset.message ||
        "I need help. Please contact me as soon as possible.";

    const contact = contacts[0];

    const phone = formatPhone(contact.phone);

    const url =
        `https://wa.me/${phone}?text=` +
        encodeURIComponent(message);

    window.open(url, "_blank");
}


/* Stop emergency alarm */

function stopSOS() {

    stopSiren();

    if (navigator.vibrate) {
        navigator.vibrate(0);
    }

    $("sosOverlay").hidden = true;

    showToast("Emergency alarm stopped.");
}


/* =====================================================
   16. FAKE INCOMING CALL
   Schedule a simulated incoming call
   ===================================================== */

function scheduleFakeCall() {

    const name =
        $("callerName").value.trim() || "Mom";

    const delay =
        Number($("callDelay").value);

    clearTimeout(fakeCallTimer);

    stopRingtone();

    $("fakeCallOverlay").hidden = true;

    showToast(
        `Fake call scheduled in ${delay} seconds.`
    );

    fakeCallTimer = setTimeout(() => {
        showFakeCall(name);
    }, delay * 1000);
}


/* Show fake call screen */

function showFakeCall(name) {

    $("fakeCallerDisplay").textContent = name;

    $("fakeCallOverlay").hidden = false;

    $("fakeCallOverlay").querySelector(
        ".call-actions"
    ).hidden = false;

    $("fakeCallOverlay").querySelector(
        ".call-end"
    ).hidden = true;

    playRingtone();
}


/* Accept simulated call */

function acceptFakeCall() {

    stopRingtone();

    $("fakeCallOverlay").querySelector(
        ".call-actions"
    ).hidden = true;

    $("fakeCallOverlay").querySelector(
        ".call-end"
    ).hidden = false;

    showToast("Simulated call accepted.");
}


/* Decline simulated call */

function declineFakeCall() {

    stopRingtone();

    $("fakeCallOverlay").hidden = true;

    showToast("Fake call declined.");
}


/* End simulated call */

function endFakeCall() {

    stopRingtone();

    $("fakeCallOverlay").hidden = true;

    showToast("Fake call ended.");
}


/* Cancel scheduled call */

function cancelFakeCall() {

    clearTimeout(fakeCallTimer);

    fakeCallTimer = null;

    stopRingtone();

    $("fakeCallOverlay").hidden = true;

    showToast("Scheduled fake call cancelled.");
}


/* =====================================================
   17. SAFE JOURNEY
   Save and share journey details
   ===================================================== */

function getTrip() {
    return getData("safeher_trip", null);
}


function saveTrip(trip) {
    saveData("safeher_trip", trip);
}


/* Start a journey */

function startJourney() {

    const destination =
        $("tripDestination").value.trim();

    const date =
        $("tripDate").value;

    const time =
        $("tripTime").value;

    const contactId =
        $("tripContact").value;

    if (!destination || !date || !time || !contactId) {
        showToast("Please complete all journey details.");
        return;
    }

    const contact = getContacts().find(
        item => String(item.id) === String(contactId)
    );

    if (!contact) {
        showToast("Please select a valid contact.");
        return;
    }

    const trip = {

        destination: destination,
        date: date,
        time: time,

        contactId: contact.id,
        contactName: contact.name,
        contactPhone: contact.phone,

        status: "active"
    };

    saveTrip(trip);

    renderTrip();

    const message =
        `My SafeHer journey has started.\n` +
        `Destination: ${destination}\n` +
        `Journey date: ${date}\n` +
        `Expected arrival: ${time}`;

    const url =
        `https://wa.me/${formatPhone(contact.phone)}?text=` +
        encodeURIComponent(message);

    window.open(url, "_blank");

    showToast("Journey saved. Please send the message.");
}


/* Display active journey */

function renderTrip() {

    const container = $("tripDetails");

    if (!container) return;

    const trip = getTrip();

    if (!trip || trip.status !== "active") {

        container.innerHTML =
            '<p class="empty-message">No active journey.</p>';

        return;
    }

    container.innerHTML = `

        <div class="trip-card">

            <h3>Active Journey</h3>

            <p>
                <strong>Destination:</strong>
                ${escapeHTML(trip.destination)}
            </p>

            <p>
                <strong>Date:</strong>
                ${escapeHTML(trip.date)}
            </p>

            <p>
                <strong>Expected Arrival:</strong>
                ${escapeHTML(trip.time)}
            </p>

            <p>
                <strong>Contact:</strong>
                ${escapeHTML(trip.contactName)}
            </p>

            <div class="trip-actions">

                <button class="trip-share"
                        data-act="shareTrip">
                    Share Journey
                </button>

                <button class="trip-arrived"
                        data-act="arrivedTrip">
                    I Arrived Safely
                </button>

                <button class="trip-cancel"
                        data-act="cancelTrip">
                    Cancel Journey
                </button>

            </div>

        </div>

    `;
}


/* Share journey again */

function shareJourney() {

    const trip = getTrip();

    if (!trip || trip.status !== "active") {
        showToast("No active journey.");
        return;
    }

    const message =
        `My SafeHer journey details:\n` +
        `Destination: ${trip.destination}\n` +
        `Date: ${trip.date}\n` +
        `Expected arrival: ${trip.time}`;

    const url =
        `https://wa.me/${formatPhone(trip.contactPhone)}?text=` +
        encodeURIComponent(message);

    window.open(url, "_blank");
}


/* Confirm safe arrival */

function arrivedSafely() {

    const trip = getTrip();

    if (!trip || trip.status !== "active") {
        showToast("No active journey.");
        return;
    }

    const message =
        `I have safely reached my destination: ${trip.destination}.`;

    const url =
        `https://wa.me/${formatPhone(trip.contactPhone)}?text=` +
        encodeURIComponent(message);

    window.open(url, "_blank");

    trip.status = "completed";

    saveTrip(trip);

    renderTrip();

    showToast("Arrival message is ready to send.");
}


/* Cancel journey */

function cancelJourney() {

    const trip = getTrip();

    if (!trip || trip.status !== "active") {
        showToast("No active journey.");
        return;
    }

    trip.status = "cancelled";

    saveTrip(trip);

    renderTrip();

    showToast("Journey cancelled.");
}


/* Fill journey contact dropdown */

function renderTripContactOptions() {

    const select = $("tripContact");

    if (!select) return;

    const previousValue = select.value;

    const contacts = getContacts();

    select.innerHTML =
        '<option value="">Select a contact</option>';

    contacts.forEach(contact => {

        const option = document.createElement("option");

        option.value = contact.id;

        option.textContent =
            `${contact.name} (${contact.phone})`;

        select.appendChild(option);
    });

    const contactExists = contacts.some(
        contact => String(contact.id) === previousValue
    );

    if (contactExists) {
        select.value = previousValue;
    }
}


/* =====================================================
   18. SAFE SPOTS
   Find nearby hospitals, police stations and more
   ===================================================== */

async function searchSafeSpot(category) {

    $("spotStatus").textContent =
        "Finding your current location...";

    try {

        // Detect current location
        const location = await getCurrentLocation();

        const latitude = location.latitude;
        const longitude = location.longitude;

        // Show OpenStreetMap inside the website
        showMap(
            "spotMap",
            latitude,
            longitude
        );

        // Search nearby places using Google Maps
        const query = encodeURIComponent(
            `${category} near ${latitude},${longitude}`
        );

        const googleMapsURL =
            `https://www.google.com/maps/search/?api=1&query=${query}`;

        $("spotStatus").innerHTML = `

            Your location has been detected.

            <br>

            Searching for ${escapeHTML(category)} near you.

            <br><br>

            <a href="${googleMapsURL}"
               target="_blank"
               rel="noopener noreferrer"
               style="color:#1F8A5B;font-weight:bold;">

                Find nearby ${escapeHTML(category)} on Google Maps

            </a>

        `;

        showToast("Your location is displayed on the map.");

    } catch (error) {

        console.error("SafeSpots location error:", error);

        if (error.code === 1) {

            $("spotStatus").textContent =
                "Location permission denied. Please allow location access.";

        } else if (error.code === 2) {

            $("spotStatus").textContent =
                "Your device could not determine your location.";

        } else if (error.code === 3) {

            $("spotStatus").textContent =
                "Location request timed out. Please try again.";

        } else {

            $("spotStatus").textContent =
                "Location is unavailable. Check your browser settings.";
        }

        showToast("Unable to find your location.");
    }
}


/* =====================================================
   19. BOTTOM NAVIGATION
   Move between website sections
   ===================================================== */

function goToSection(sectionId) {

    const section = $(sectionId);

    if (!section) return;

    section.scrollIntoView({
        behavior: "smooth",
        block: "start"
    });

    document.querySelectorAll(".nav-item").forEach(button => {

        button.classList.toggle(
            "active",
            button.dataset.section === sectionId
        );

    });
}


/* =====================================================
   20. BUTTON EVENT HANDLER
   Connect HTML buttons with JavaScript functions
   ===================================================== */

document.addEventListener("click", (event) => {

    // Bottom navigation buttons
    const navButton = event.target.closest("[data-section]");

    if (navButton) {

        goToSection(navButton.dataset.section);

        return;
    }


    // SafeSpots category buttons
    const spotButton = event.target.closest("[data-spot]");

    if (spotButton) {

        searchSafeSpot(spotButton.dataset.spot);

        return;
    }


    // Delete contact buttons
    const deleteButton =
        event.target.closest("[data-delete-contact]");

    if (deleteButton) {

        deleteContact(
            Number(deleteButton.dataset.deleteContact)
        );

        return;
    }


    // General action buttons
    const actionButton = event.target.closest("[data-act]");

    if (!actionButton) return;

    const action = actionButton.dataset.act;


    // Action list
    const actions = {

        // Emergency
        sos: activateSOS,
        testSiren: playSiren,
        stopSos: stopSOS,
        sosWhatsApp: shareSOSWhatsApp,

        // Location
        getLocation: findMyLocation,
        shareWhatsApp: shareWhatsApp,
        shareSMS: shareSMS,
        nativeShare: nativeShare,

        // Fake Call
        scheduleCall: scheduleFakeCall,
        cancelCall: cancelFakeCall,
        acceptCall: acceptFakeCall,
        declineCall: declineFakeCall,
        endCall: endFakeCall,

        // Contacts
        addContact: addContact,

        // Journey
        startTrip: startJourney,
        shareTrip: shareJourney,
        arrivedTrip: arrivedSafely,
        cancelTrip: cancelJourney
    };


    // Run selected action
    if (actions[action]) {
        actions[action]();
    }

});


/* =====================================================
   21. INITIAL WEBSITE SETUP
   Run when the website loads
   ===================================================== */

function initializeSafeHer() {

    // Set today's date in journey form
    const today = new Date();

    const localDate = new Date(
        today.getTime() -
        today.getTimezoneOffset() * 60000
    ).toISOString().split("T")[0];

    if ($("tripDate")) {
        $("tripDate").value = localDate;
    }

    // Load saved contacts
    renderContacts();

    // Load saved journey
    renderTrip();

    // No login required
    console.log(
        "SafeHer is ready. No Firebase or login required."
    );
}


/* =====================================================
   22. START WEBSITE
   ===================================================== */

document.addEventListener(
    "DOMContentLoaded",
    initializeSafeHer
);
